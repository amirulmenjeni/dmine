Run install.sh to install dmine.
